import 'dart:ui';

Color green1=const Color(0xff064506);
Color green2=const Color(0xff2A3923);
Color
txtclr=const Color(0xff2A3923);
Color white=const Color(0xffFFFFFF);
Color green3=const Color(0xff0F2704);
Color f1=const Color(0xff9E9F9A);
Color lightgreen=Color(0xff677C33);