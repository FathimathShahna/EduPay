// import 'dart:io';
//
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:yorent/PROVIDER/mainProvider.dart';
// import 'utils.dart';
// import 'package:video_player/video_player.dart';
// import 'resources/save_video.dart';
//
// class video extends StatefulWidget {
//    video({super.key});
//
//   @override
//   State<video> createState() => _videoState();
// }
//
// class _videoState extends State<video> {
//   String? _videoURL;
//   VideoPlayerController? _controller;
//   String? _downloadURL;
//   @override
//   void dispose(){
//     _controller?.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         backgroundColor: Colors.blue,
//         title: Text('Video Upload'),
//       ),
//       body: Center(
//         child: _videoURL != null
//         ?Container(
//             height: 500,
//             width: 250,
//             child: _videoPreviewWidget())
//         : Text('No Video Selected'),
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: _pickVideo,
//         child: Icon(Icons.video_library),
//       ),
//     );
//   }
//   void _pickVideo() async{
//     _videoURL =  await pickVideo();
//     _initializeVideoPlayer();
//   }
//   void _initializeVideoPlayer(){
//     _controller = VideoPlayerController.file(
//       File(_videoURL!))
//     ..initialize().then((_)  {
//       setState(() {});
//       _controller!.play();
//     });
//   }
//   Widget _videoPreviewWidget(){
//     if(_controller != null){
//       return Column(
//         children: [
//           AspectRatio(
//             aspectRatio: _controller!.value.aspectRatio,
//             child: VideoPlayer(_controller!),
//           ),
//           ElevatedButton(onPressed: _uploadVideo, child: Text('Upload')),
//         ],
//       );
//     }
//     else{
//       return CircularProgressIndicator();
//     }
//   }
//
//   y
// }


