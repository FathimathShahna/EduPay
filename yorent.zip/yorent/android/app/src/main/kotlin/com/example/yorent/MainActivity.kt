package com.example.yorent

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
