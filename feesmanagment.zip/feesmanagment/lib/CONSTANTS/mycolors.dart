import 'package:flutter/material.dart';

const clWhite= Colors.white;
const clBlack= Colors.black;
const themecolor=Color(0xFF000080);
const clE5E8E8 =Color(0xFFE5E8E8 );
const clD6EAF8 =Color(0xFFD6EAF8 );
const clAEB6BF =Color(0xFFAEB6BF);
