package com.example.feesmanagment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
